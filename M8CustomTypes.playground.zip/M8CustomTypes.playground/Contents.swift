import UIKit

//struct, class, enum

/*struct
 struct StructName{
    properties
    methods
    initializers
 }
 */

struct Person{
    var name: String
    var age: Int
    
    func speak(){
        print("Hello")
    }
}

let person = Person(name: "John", age: 30)
person.name
person.age
person.speak()

var p = person
p.name = "Kim"
person.name
p.name

/*
 class ClassName{
    properties (stored & type & computer properties)
    methods (instance methods, type methods)
    initializers
    deinitializers
 }
 
 */


class PersonClass{ //designated initializer
    var name: String //stored preperties, instance properties
    var age: Int
    var nextYearAge: Int{
        get{ return age + 1}
        set(newValue){age = newValue - 1}
    }
    init(name: String, age: Int){
        self.name = name
        self.age = age
    }
    
    
    func speak(){
        print("Class Hello!")
    }
    
    class func speakType1(){
        print("Type method 1.")
    }
    
    class func speakType2(){
        print("Type method 2.")
    }
}


let p2 = PersonClass(name: "Jane", age: 25)

var p3 = p2
p3.name = "EM"
p2.name
p3.name

p2.nextYearAge
p2.nextYearAge = 100
PersonClass.speakType1()
PersonClass.speakType2()

/*
 enum: a group of related values
 enum TypeName{
    case caseName
    case caseName, caseName
 
    properties
    methods
    initializers
 }
 */

//eft 0
//center 1
//right 2


/*
let left = "left"
let center = "center"
let right = "right"

let alignment = center

if alignment == "center"{
    print("center")
}

*/


enum Alignment{
    case left
    case center
    case right
}

let leftAlign = Alignment.left
